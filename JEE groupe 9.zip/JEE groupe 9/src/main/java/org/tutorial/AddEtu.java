package org.tutorial;
import java.io.IOException;
import java.io.PrintWriter;

import org.Beans.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.Beans.User;
import org.Beans.UserDAO;
import org.Beans.UserDAOImpl;
import org.Beans.Etudiant;
import org.Beans.EtudiantDAO;
import org.Beans.EtudiantDAOImpl;
import org.Forms.InscriptionForm;
public class AddEtu extends HttpServlet {
    public static final String ATT_USER = "utilisateur";
    public static final String ATT_FORM = "form";
    public static final String VUE = "/WEB-INF/addEtu.jsp";

    public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Affichage de la page d'inscription */
        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    }

    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Préparation de l'objet formulaire */
        EtudiantDAO cd = new EtudiantDAOImpl();
        String numetudiant = request.getParameter("numetudiant");
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String ddn = request.getParameter("ddn");
        String emailPro = request.getParameter("emailPro");
        String emailPerso = request.getParameter("emailPerso");
        String bac = request.getParameter("bac");
        String anBac = request.getParameter("anBac");
        String menBac = request.getParameter("menBac");
        String diplome = request.getParameter("diplome");
        String anDiplome = request.getParameter("anDiplome");
        String villeDiplome = request.getParameter("villeDiplome");
        String S = request.getParameter("S");
        String inscription = request.getParameter("inscription");
        String submitType = request.getParameter("submit");
        boolean c = cd.setEtudiant(numetudiant,nom,prenom,ddn,emailPro,emailPerso,bac,anBac,menBac,diplome,anDiplome,villeDiplome,S,inscription);
        System.out.print(c);

        if (c) {
            response.sendRedirect( request.getContextPath() + "/HelloWorld" );
        } else {
            response.sendRedirect( request.getContextPath() + "/addetu" );
        }
    }
}