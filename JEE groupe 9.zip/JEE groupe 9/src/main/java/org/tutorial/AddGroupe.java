package org.tutorial;
import java.io.IOException;
import java.io.PrintWriter;

import org.Beans.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.Beans.User;
import org.Beans.UserDAO;
import org.Beans.UserDAOImpl;
import org.Beans.Etudiant;
import org.Beans.EtudiantDAO;
import org.Beans.EtudiantDAOImpl;
import org.Forms.InscriptionForm;
public class AddGroupe extends HttpServlet {
    public static final String ATT_USER = "utilisateur";
    public static final String ATT_FORM = "form";
    public static final String VUE = "/WEB-INF/addGroupe.jsp";

    public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Affichage de la page d'inscription */
        this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
    }

    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException{
        /* Préparation de l'objet formulaire */
        GroupeDAO cd = new GroupeDAOImpl();
        String nomgrp = request.getParameter("nomgrp");
        String proprio = request.getParameter("proprio");
        String date = request.getParameter("date");
        boolean c = cd.setGroupe(nomgrp,proprio,date);
        System.out.print(c);

        if (c) {
            response.sendRedirect( request.getContextPath() + "/HelloWorld" );
        } else {
            response.sendRedirect( request.getContextPath() + "/addgroupe" );
        }
    }
}