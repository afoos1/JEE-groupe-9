package org.tutorial;
import org.Forms.*;
import org.Beans.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.Beans.User;

public class Connexion extends HttpServlet {


    public static final String ATT_USER = "pseudo";

    public static final String ATT_FORM = "form";

    public static final String ATT_INTERVALLE_CONNEXIONS = "intervalleConnexions";

    public static final String ATT_SESSION_USER = "sessionUtilisateur";

    public static final String COOKIE_DERNIERE_CONNEXION = "derniereConnexion";

    public static final String FORMAT_DATE = "dd/MM/yyyy HH:mm:ss";

    public static final String VUE = "/WEB-INF/connexion.jsp";

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /* Affichage de la page de connexion */
        this.getServletContext().getRequestDispatcher(VUE).forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String ATT_USER         = "utilisateur";
        UserDAO cd = new UserDAOImpl();
        String ATT_FORM = "form";
        String ATT_SESSION_USER = "sessionUtilisateur";
        String pseudo = request.getParameter("pseudo");//ou username
        String mdp = request.getParameter("password");//ou password
        System.out.println("request "+mdp);
        String submitType = request.getParameter("submit");
        User c = cd.getUser(pseudo,mdp);
        System.out.println(c);
        System.out.println("mdp = "+mdp);
        System.out.println("getmdp ="+ c.getPassword());
        String ACCES_PUBLIC = "/accesPublic.jsp";


        /**
         * Si aucune erreur de validation n'a eu lieu, alors ajout du bean
         * Utilisateur à la session, sinon suppression du bean de la session.
         */


        HttpSession session = request.getSession();


            if (/*submitType.equals("Connexion") && */c != null && mdp.equals(c.getPassword())) {
                if (c.getAdmin()) {
                    response.sendRedirect(request.getContextPath() + "/admin");
                    session.setAttribute("etat", "/admin");
                } else if (c.getEditor()) {
                    response.sendRedirect(request.getContextPath() + "/editor");
                    session.setAttribute("etat", "/editor");

                } else {
                    response.sendRedirect(request.getContextPath() + "/user");
                    session.setAttribute("etat", "/user");

                }
            } else {
                response.sendRedirect(request.getContextPath() + "/connexion");
            }
        }
    }

