package org.tutorial;
import java.io.IOException;
import org.Beans.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


import org.Beans.User;
import org.Beans.UserDAO;
import org.Beans.UserDAOImpl;
import org.Forms.InscriptionForm;

public class Editor extends HttpServlet {
    public static final String ATT_USER = "utilisateur";
    public static final String ATT_FORM = "form";
    public static final String VUE = "/WEB-INF/editor.jsp";
    public static final String ACCES_PUBLIC = "/accesPublic.jsp";
    public static final String ACCES_RESTREINT = "/WEB-INF/accesRestreint.jsp";
    public static final String ATT_SESSION_USER = "sessionUtilisateur";

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /* Affichage de la page d'inscription */

        this.getServletContext().getRequestDispatcher(VUE).forward(request, response);

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /* Préparation de l'objet formulaire */
        UserDAO cd = new UserDAOImpl();/*
        String user = request.getParameter("pseudo");//ou username
        String mdp = request.getParameter("password");//ou password
        String question = request.getParameter("question");
        String answer = request.getParameter("answer");
        */
        HttpSession session = request.getSession();


        String submitType2 = request.getParameter("affichage_etudiants");
        String submitType3 = request.getParameter("addEtu");
        String submitType4 = request.getParameter("delEtu");
        String submitType5 = request.getParameter("Deconnexion");
        String submitType7 = request.getParameter("modetu");
        String submitType8 = request.getParameter("addgroupe");
        String submitType9 = request.getParameter("delgroupe");
        String submitType10 = request.getParameter("addetugroupe");


        if (submitType2 != null) {
            response.sendRedirect(request.getContextPath() + "/affichage_etudiants");

        } else {


            if (submitType3 != null) {

                response.sendRedirect(request.getContextPath() + "/addetu");
            } else {

                if (submitType4 != null) {

                    response.sendRedirect(request.getContextPath() + "/deletu");

                } else {

                    if (submitType5 != null) {
                        response.sendRedirect(request.getContextPath() + "/deconnexion");
                    } else {

                        if (submitType7 != null) {

                            response.sendRedirect(request.getContextPath() + "/choixmodetu");
                        } else {
                            if (submitType8 != null) {

                                response.sendRedirect(request.getContextPath() + "/addgroupe");
                            } else {

                                if (submitType9 != null) {

                                    response.sendRedirect(request.getContextPath() + "/delgroupe");

                                } else {

                                    if (submitType10 != null) {
                                        response.sendRedirect(request.getContextPath() + "/addetugroupe");
                                    } else {


                                        response.sendRedirect(request.getContextPath() + "/inscription");
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
}








