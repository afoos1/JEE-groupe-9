package org.Beans;


public class User {

    private String password;
    private String pseudo;
    private String question;
    private String answer;
    private Boolean isEditor;
    private Boolean isAdmin;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Boolean getEditor() {
        return isEditor;
    }

    public void setEditor(Boolean editor) {
        isEditor = editor;
    }

    public Boolean getAdmin() {
        return isAdmin;
    }

    public void setAdmin(Boolean admin) {
        isAdmin = admin;
    }

    public User(String motDePasse, String pseudo, String question, String answer, Boolean editor, Boolean admin) {
        this.password = motDePasse;
        this.pseudo = pseudo;
        this.question = question;
        this.answer = answer;
        this.isEditor = editor;
        this.isAdmin = admin;
    }

    public User(){}

    public void setPassword(String password) {
        this.password = password;
    }
    public String getPassword() {
        return password;
    }

    public User(String password, String pseudo) {
        this.password = password;
        this.pseudo = pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }
    public String getPseudo() {
        return pseudo;
    }
}
