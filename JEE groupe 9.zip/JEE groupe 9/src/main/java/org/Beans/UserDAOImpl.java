package org.Beans;

import org.tutorial.DBManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of Book DAO to get books from DB
 *
 * @see UserDAO
 *
 */
public class UserDAOImpl implements UserDAO {


    /**
     * common method used to query DB
     *
     * @param query the SQL query to use
     * @return a list of books built from the SQL query
     */
    public List<User> findBy(String query) {
        Connection conn = null;
        List<User> listUser = new ArrayList<User>();

        Statement stat = null;
        ResultSet rs = null;
        try {
            conn = DBManager.getInstance().getConnection();
            if (conn != null) {
                stat = conn.createStatement();
                rs = stat.executeQuery(query);
                while (rs.next()) {
                    //int id = rs.getInt("id");
                    String pseudo = rs.getString("pseudo");
                    String password = rs.getString("password");
                    listUser.add(new User(pseudo, password));
                }
            }
        } catch (Exception e) {
            // TODO: handle exception : main exception should thrown to servlet
            // layer to display error message
            e.printStackTrace();

        } finally {
            // always clean up all resources in finally block
            if (conn != null) {
                DBManager.getInstance().cleanup(conn, stat, rs);
            }
        }
        return listUser;
    }

    public List<User> findByAll() {
        // avoid select * queries because of performance issues,
        // only query the columns you need
        return findBy("select id,pseudo,password from user");
    }

    public List<User> findByPseudo(String searchText) {
        // watch out : this query is case sensitive. use upper function on title
        // and searchText to make it case insensitive
        return findBy("select id,pseudo,password from user where pseudo='" + searchText + "'");
    }

    public List<User> findByLogin(String pseudo, String password) {
        return findBy("select id,pseudo,password from user where pseudo like '%" + pseudo + "%' and password like '%" + password + "%' ");
    }

    public User getUser(String pseudo, String password) {

        User c = new User();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con = DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement = con.prepareStatement("select * from users where pseudo=? and password=?;");
            statement.setString(1, pseudo);
            statement.setString(2, password);

            ResultSet rs = statement.executeQuery();
            System.out.println("peseud");
            while (rs.next()) {
                c.setPseudo(rs.getString(1));

                c.setPassword(rs.getString(2));
                System.out.println("peseudo : " + c.getPseudo() + " " + c.getPassword());
                c.setQuestion(rs.getString(3));
                c.setAnswer(rs.getString(4));
                c.setAdmin(rs.getBoolean(6));
                c.setEditor(rs.getBoolean(5));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("user:" + c);
        return c;
    }

    public boolean setUser(String pseudos, String passwords, String question, String answer) {
        try {

            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con = DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement = con.prepareStatement("INSERT INTO users (pseudo, password, question, answer) "
                    + "VALUES ('" + pseudos + "', '" + passwords + "' , '" + question + "', '" + answer + "');");
            //statement.setString(1, pseudo);
            //statement.setString(2, password);

            int rs = statement.executeUpdate();
            System.out.println(rs);
            if (rs == 1) {
                return true;
            }

        } catch (Exception e) {
            System.out.println(e);

        }
        return false;
    }

    public void showUsers() {
        try {


            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con = DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement = con.prepareStatement("select * from users;");
            //statement.setString(1, pseudo);
            //statement.setString(2, password);

            ResultSet rs = statement.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            while (rs.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    if (i > 1) System.out.print(",  ");
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue + " " + rsmd.getColumnName(i));
                }
                System.out.println(" ");
            }
            System.out.println("end requete sql");


        } catch (Exception e) {
            System.out.println(e);
        }

    }
}