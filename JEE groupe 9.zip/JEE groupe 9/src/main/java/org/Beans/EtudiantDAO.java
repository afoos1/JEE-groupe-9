package org.Beans;

import java.util.List;

public interface EtudiantDAO {

    /**
     * find all students without any criteria
     *
     * @return a list of Etudiant objects
     */
    List<Etudiant> findByAll();

    /**
     * find by whose name contains a string
     *
     * @param searchText
     *            the pattern to search
     * @return a list of students whose name contains searchText
     */
    List<Etudiant> findByName(String searchText);

    /**
     * find by whose id contains an int
     *
     * @param searchId
     *            the pattern to search
     * @return a list of student whose id contains searchId
     */
    Etudiant findById(int searchId);


    boolean setEtudiant(String numetudiant, String nom, String prenom, String ddn, String emailPro, String emailPerso,
                        String bac, String anBac, String menBac, String diplome, String anDiplome, String villeDiplome,
                        String S, String inscription);
    boolean delEtudiant(String numetudiant);

    Etudiant getEtudiant(String numetudiant);
}
