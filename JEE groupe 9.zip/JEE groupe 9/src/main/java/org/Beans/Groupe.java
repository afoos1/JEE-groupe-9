package org.Beans;

import org.Beans.Etudiant;

import java.util.List;
import java.util.Date;


public class Groupe {
    private String nom;
    private String proprietaire;
    private String dateCreation;
    private int len;
    private Etudiant[] membres;


    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getProprietaire() {
        return proprietaire;
    }

    public void setProprietaire(String proprietaire) {
        this.proprietaire = proprietaire;
    }

    public String getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Etudiant[] getMembres() {
        return membres;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public void setMembres(Etudiant[] membres) {
        this.membres = membres;
    }

    public Groupe(String nom, String proprietaire, String dateCreation, Etudiant[] membre) {
        this.nom = nom;
        this.proprietaire = proprietaire;
        this.dateCreation = dateCreation;
        this.membres = membre;
    }

    public void modif(String nom, String proprietaire, String dateCreation, Etudiant[] membre){
        this.nom = nom;
        this.proprietaire = proprietaire;
        this.dateCreation = dateCreation;
        this.membres = membre;
    }

    public void suppr(){
        this.nom = null;
        this.proprietaire = null;
        this.dateCreation = null;
        this.membres = null;
    }

    public Groupe clone(){
        return this;
    }

    public void add(Etudiant e){
        this.membres[len]=e;
        this.len = this.len + 1;
    }

    public void add(Groupe g) {
        int n = g.len;
        int i=0;
        while (i<n){
            Etudiant e = g.membres[i];
            this.add(e);
            i++;
        }
    }
}