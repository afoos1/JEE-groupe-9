package org.Beans;
import java.sql.ResultSet;
import java.util.List;

public interface UserDAO {

    List<User> findBy(String query);

    List<User> findByAll();

    List<User> findByLogin(String pseudo, String password);

    List<User> findByPseudo(String searchText);

    User getUser(String pseudo, String password);

    boolean setUser(String pseudo, String password, String question, String answer);

    void showUsers();

    }