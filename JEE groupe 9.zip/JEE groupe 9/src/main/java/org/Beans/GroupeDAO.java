package org.Beans;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

public interface GroupeDAO {

    boolean setGroupe(String nom,String proprietaire, String dateCreation );

    boolean delGroupe(String nom);

    String[] getEtuInGroupe(String nom);

    boolean addEtuGroupe(String nomGroupe, String nomEtu );

    boolean delEtuGroupe (String nomGroupe, String nomEtu);

}