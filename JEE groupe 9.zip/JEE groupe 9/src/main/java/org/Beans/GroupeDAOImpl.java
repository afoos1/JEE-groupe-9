package org.Beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

public class GroupeDAOImpl implements GroupeDAO{



    public boolean setGroupe(String nom, String proprietaire, String dateCreation){
        try {

            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("INSERT INTO Groupes VALUES ('" + nom + "', '" + proprietaire+ "' , '" + dateCreation + "');");
            int rs = statement.executeUpdate();
            System.out.println(rs);
            if(rs==1){
                return true;
            }
        }catch(Exception e) {
            System.out.println(e);

        }
        return false;
    }



    @Override
    public boolean delGroupe(String nom) {

        try {

            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("DELETE FROM groupes where nomGroupe=?;");
            statement.setString(1, nom);

            int rs = statement.executeUpdate();
            System.out.println(rs);
            if(rs==1){
                return true;
            }
        }catch(Exception e) {
            System.out.println(e);

        }
        return false;
    }

    @Override
    public String[] getEtuInGroupe(String nom){

        String[] c= new String[50];
        int i=0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("select numetudiant from listeetusdiants where numgroupe=?;");
            statement.setString(1, nom);

            ResultSet rs = statement.executeQuery();
            while(rs.next() && i<50) {
                c[i]=(rs.getString(1));
                i++;
            }
        }catch(Exception e) {
            System.out.println(e);
        }
        System.out.println("user:"+c);
        return c;

    }

    @Override
    public boolean addEtuGroupe(String nomGroupe, String nomEtu) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("insert into listeetudiants values (?,?);");
            statement.setString(2, nomGroupe);
            statement.setString(1,nomEtu);

            int rs = statement.executeUpdate();
            if(rs==1){
                return true;
            }
        }catch(Exception e) {
            System.out.println(e);
        }
        return false;
    }

    @Override
    public boolean delEtuGroupe(String nomGroupe, String nomEtu) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("delete from listeetudiants where nomGroupe=? and numetudiant=?;");
            statement.setString(1, nomGroupe);
            statement.setString(1,nomEtu);
            int rs = statement.executeUpdate();
            if(rs==1){
                return true;
            }
        }catch(Exception e) {
            System.out.println(e);
        }

        return false;
    }
}
