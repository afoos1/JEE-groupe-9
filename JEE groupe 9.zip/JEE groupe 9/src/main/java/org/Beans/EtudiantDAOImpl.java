package org.Beans;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;

import org.tutorial.DBManager;

/**
 * Implementation of Etudiant DAO to get students from DB
 *
 * @see EtudiantDAO
 *
 */
public class EtudiantDAOImpl implements EtudiantDAO {

    /**
     * common method used to query DB
     *
     * @param query
     *            the SQL query to use
     * @return a list of students built from the SQL query
     */
    private List<Etudiant> findBy(String query) {
        Connection conn = null;
        List<Etudiant> listStudents = new ArrayList<Etudiant>();
        Statement stat = null;
        ResultSet rs = null;
        try {
            conn = DBManager.getInstance().getConnection();
            if (conn != null) {
                stat = conn.createStatement();
                rs = stat.executeQuery(query);
                while (rs.next()) {
                    String numetudiant = rs.getString("numetudiant");
                    String prenom = rs.getString("prenom");
                    String nom = rs.getString("nom");
                    String s = rs.getString("S");
                    String d2 = rs.getString("anBac");
                    String d3 = rs.getString("anDiplome");
                    String d1 = rs.getString("ddn");
                    String cp = rs.getString("emailPro");
                    String c = rs.getString("emailPerso");
                    String l = rs.getString("bac");
                    String m = rs.getString("menBac");
                    String i = rs.getString("inscription");
                    String d = rs.getString("diplome");
                    String v = rs.getString("villeDiplome");
                    listStudents.add(new Etudiant(numetudiant, prenom, nom, s, d1, d2, d3, cp, c, l, m, i, d, v));
                }
            }
        } catch (Exception e) {
            // TODO: handle exception : main exception should thrown to servlet
            // layer to display error message
            e.printStackTrace();

        } finally {
            // always clean up all resources in finally block
            if (conn != null) {
                DBManager.getInstance().cleanup(conn, stat, rs);
            }
        }
        return listStudents;
    }

    private void insertEtu(Etudiant etu ) {

        Connection conn = null;
        //List<Etudiant> listStudents = new ArrayList<Etudiant>();
        Statement stat = null;
        ResultSet rs = null;
        try {
            conn = DBManager.getInstance().getConnection();
            if (conn != null) {
                stat = conn.createStatement();
                String id = etu.getNumetudiant();
                String nom = etu.getNom();
                String prenom = etu.getPrenom();
                String d1 = etu.getDateNaissance();
                String cp = etu.getPro();
                String c =  etu.getPerso();
                String b = etu.getBac();
                String d2 = etu.getDateBac();
                String m = etu.getMention();
                String d = etu.getDiplome();
                String d3 = etu.getDateDiplome();
                String v = etu.getVilleDiplome();
                String s = etu.getS();
                String i = etu.getInscription();
                String query = "insert into Etudiant values ('" + id + "','" + nom + "','" + prenom + "','" + d1 +
                        "','" + cp + "','" + c + "','" + b + "','" + d2 + "','" + m + "','" + d + "','" + d3 + "','" + v + "','" + s + "','" + i + "');";
                rs = stat.executeQuery(query);
            }
        } catch (Exception e) {
            // TODO: handle exception : main exception should thrown to servlet
            // layer to display error message
            e.printStackTrace();

        } finally {
            // always clean up all resources in finally block
            if (conn != null) {
                DBManager.getInstance().cleanup(conn, stat, rs);
            }
        }
    }

    public List<Etudiant> findByAll() {
        // avoid select * queries because of performance issues,
        // only query the columns you need
        return findBy("select numetudiant,nom, prenom, ddn, emailPro, emailPerso, bac, anBac, menBac, diplome, anDiplome, villeDiplome S inscription from Etudiants");
        //TODO corriger avec les bons parametres de la BDD
    }


    /**
     * common method used print all students
     *
     * @param l
     *            a list of Etudiant to use
     * Display all students in the list
     *
     */

    public void afficher(List<Etudiant> l){
        int n = l.size();
        int k=0;
        while (k<n) {
            System.out.println(l.get(k));
            k++;
        }

    }

    // recherche l'etudiant par son prenom (pas son nom)
    public List<Etudiant> findByName(String searchText) {
        // watch out : this query is case sensitive. use upper function on title
        // and searchText to make it case insensitive
        return findBy("select numetudiant,nom, prenom, ddn, emailPro, emailPerso, bac, anBac, menBac, diplome, anDiplome, villeDiplome S inscription from Etudiants where prenom like '%" + searchText + "%'");

    }
    // recherche l'etudiant par son identifiant (donc un seul etudiant)
    public Etudiant findById(int searchId) {
        // watch out : this query is case sensitive. use upper function on title
        // and searchText to make it case insensitive
        List<Etudiant> tab;
        tab = findBy("select numetudiant,nom, prenom, ddn, emailPro, emailPerso, bac, anBac, menBac, diplome, anDiplome, villeDiplome S inscription from Etudiants where numetudiant like '" + searchId +"'");
        return tab.get(0);
    }

    public void supprimerEtu(int etuId, List<Etudiant> l){
        List<Etudiant> tab;
        Etudiant etu;
        tab = findBy("select numetudiant,nom, prenom, ddn, emailPro, emailPerso, bac, anBac, menBac, diplome, anDiplome, villeDiplome S inscription from students where numetudiant like '" + etuId +"'");
        etu = tab.get(0);
        l.remove(etu);

    }

    public boolean setEtudiant(String numetudiant, String nom, String prenom, String ddn,String emailPro, String emailPerso,
                               String bac, String anBac, String menBac, String diplome, String anDiplome, String villeDiplome,
                               String S, String inscription){
        try {

            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("INSERT INTO etudiants (numetudiant,nom,prenom,ddn,emailPro,emailPerso,bac,anBac,menBac,diplome,anDiplome,villeDiplome,S,inscription)"
                    + "VALUES ('" + numetudiant + "', '" + nom + "' , '" + prenom + "', '" + ddn + "', '" + emailPro + "', '" + emailPerso + "', '" + bac + "', '" + anBac + "', '" + menBac + "', '" + diplome + "', '" + anDiplome + "', '" + villeDiplome + "', '" + S + "', '" + inscription + "');");
            //statement.setString(1, pseudo);
            //statement.setString(2, password);

            int rs = statement.executeUpdate();
            System.out.println(rs);
            if(rs==1){
                return true;
            }

        }catch(Exception e) {
            System.out.println(e);

        }
        return false;
    }

    public boolean delEtudiant(String numetudiant){

        try {

            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement2 =con.prepareStatement("DELETE FROM ListeEtudiants where numetudiant=?;");
            PreparedStatement statement =con.prepareStatement("DELETE FROM etudiants where numetudiant=?;");
            statement.setString(1, numetudiant);
            statement2.setString(1, numetudiant);

            //statement.setString(2, password);
            statement2.execute();
            int rs = statement.executeUpdate();
            System.out.println(rs);
            if(rs==1){
                return true;
            }

        }catch(Exception e) {
            System.out.println(e);

        }
        return false;
    }

    public Etudiant getEtudiant(String numetudiant){
        Etudiant c= new Etudiant();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/enssat?characterEncoding=latin1&useConfigs=maxPerformance";
            String utilisateur = "test";
            String motDePasse = "password";
            Connection con= DriverManager.getConnection(url, utilisateur, motDePasse);
            PreparedStatement statement =con.prepareStatement("select * from etudiants where numetudiant=?;");
            statement.setString(1, numetudiant);

            ResultSet rs = statement.executeQuery();
            while(rs.next()) {
                c.setNumetudiant(rs.getString(1));
                c.setNom(rs.getString(2));
                c.setPrenom(rs.getString(3));
                c.setDateNaissance(rs.getString(4));
                c.setPro(rs.getString(5));
                c.setPerso(rs.getString(6));
                c.setBac(rs.getString(7));
                c.setDateBac(rs.getString(8));
                c.setMention(rs.getString(9));
                c.setDiplome(rs.getString(10));
                c.setDateDiplome(rs.getString(11));
                c.setVilleDiplome(rs.getString(12));
                c.setS(rs.getString(13));
                c.setInscription(rs.getString(14));
            }
        }catch(Exception e) {
            System.out.println(e);
        }
        System.out.println("user:"+c);
        return c;
    }

 /*
    public ResultSet getGroupOfEtu(HttpServletRequest request) {
        Connection connexion = null;
        PreparedStatement statement = null;
        String numetudiant = (String) request.getParameter("numetudiant");

        // Connexion à la base de données
        try {
            connexion = (Connection) DBManager.getInstance().getConnection();
           // Verification pseudo

            statement = (PreparedStatement) connexion.prepareStatement("select nomGroupe from Groupes where idGroupe in " +
                    "(select idGroupe from ListeEtudiant where numetudiant = ?);");
            statement.setString(1, numetudiant);
            return (statement.executeQuery());

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public ResultSet getSameProfile() {
        Connection connexion = null;
        PreparedStatement statement = null;

        // Connexion à la base de données
        try {
            connexion = (Connection) DBManager.getInstance().getConnection();
            //Verification pseudo

            statement = (PreparedStatement) connexion.prepareStatement("select * from Etudiants order by bac, diplome;");
            return (statement.executeQuery());

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

   */




}