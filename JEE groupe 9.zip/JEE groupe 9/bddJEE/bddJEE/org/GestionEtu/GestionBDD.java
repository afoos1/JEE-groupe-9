package org.GestionEtu;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.util.Enumeration;
//import java.util.Properties;
//import java.util.ResourceBundle;;
import java.util.*;


public class GestionBDD {
	
	
	
	private List<String> messages = new ArrayList<String>();
	
	
	private static GestionBDD gestion = new GestionBDD();
	
	private GestionBDD() {
		 /* Chargement du driver JDBC pour MySQL */
		try {
	        Class.forName( "com.mysql.jdbc.Driver" );
	    } catch ( ClassNotFoundException e ) {
	    	e.printStackTrace();
	    }
	}
	
	public static GestionBDD getInstance() {
		return gestion;
	}
	
	//Méthode de test de l'utilisateur 
	public boolean isUser(HttpServletRequest request) throws SQLException {
		boolean isUser = false;
		Connection connexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultat = null;

    
	    String pseudo = (String) request.getParameter("pseudo");
	    String mdp = (String) request.getParameter("password");
	    
	    
	    if(pseudo != null && mdp != null) {
	    	//vérification des pseudo et mot de passe dans la base de donnée 
	    	try {
	    		Class.forName("com.mysql.jdbc.Driver");
		        connexion = (Connection) DriverManager.getInstance().getConnection();
	    		statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Users where pseudo=? and password=?");
		        statement.setString(1, pseudo);
		        statement.setString(2,  mdp);
		        resultat = statement.executeQuery();
	        } catch ( SQLException e ) {
	        	e.printStackTrace();
		    } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
		        if ( resultat != null ) {
		            try {
		            	//S'il y a un utilisateur dans la base de données avec le pseudo et le mot de passe voulus, isUser passe à True
		            	isUser= found(resultat);
		                resultat.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
		        if ( statement != null ) {
		            try {
		                statement.close();
		            } catch ( SQLException ignore ) {
		            }
		        }
		        if ( connexion != null ) {
		            try {
		                connexion.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
			}
	    }
	    return isUser;
	}


	//Méthode renvoyant les droits d'un utilisateur dans un tableau (de longueur 3)
	public boolean[] getStatus(HttpServletRequest request) throws SQLException {
		boolean  [] status = new boolean[3];//Position 0 : isUser //Position 1  isEditor //Position 2 : isAdmin
		Connection connexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultat = null;
	    String pseudo = (String) request.getParameter("pseudo");
	    String mdp = (String) request.getParameter("password");
	    
	    if(pseudo != null && mdp != null) {
	    	try {
	    		Class.forName("com.mysql.jdbc.Driver");
		        connexion = (Connection) DriverManager.getInstance().getConnection();
	    		statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Users where pseudo=? and password=?");
		        statement.setString(1, pseudo);
		        statement.setString(2,  mdp);
		        resultat = statement.executeQuery();
	        } catch ( SQLException e ) {
	        	e.printStackTrace();
		    } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
		        if ( resultat != null ) {
		            try {
		            	if(found(resultat)) {
		            		status[0] = true;
		            		status[1] = resultat.getBoolean("isEditor");
		            		status[2] = resultat.getBoolean("isAdmin");
		            	}
		                resultat.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
		        if ( statement != null ) {
		            try {
		                statement.close();
		            } catch ( SQLException ignore ) {
		            }
		        }
		        if ( connexion != null ) {
		            try {
		                connexion.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
			}
	    }
	    return status;
	}

	//Méthode de test de l'editeur
	public boolean isEditor(HttpServletRequest request) throws SQLException {
		Connection connexion = null;
		PreparedStatement statement = null;
		ResultSet resultat = null;
		boolean isAdmin = false;
		String pseudo = (String) request.getParameter("pseudo");
		String mdp = (String) request.getParameter("password");

		if(pseudo != null && mdp != null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connexion = (Connection) DriverManager.getInstance().getConnection();
				statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Users where pseudo=? and password=?");
				statement.setString(1, pseudo);
				statement.setString(2,  mdp);
				resultat = statement.executeQuery();
			} catch ( SQLException e ) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {

				if ( resultat != null ) {
					try {
						if(found(resultat)) {
							isAdmin= resultat.getBoolean("isEditor");
						}
						resultat.close();
					} catch ( SQLException ignore ) {
						ignore.printStackTrace();
					}
				}
				if ( statement != null ) {
					try {
						statement.close();
					} catch ( SQLException ignore ) {
					}
				}
				if ( connexion != null ) {
					try {
						connexion.close();
					} catch ( SQLException ignore ) {
						ignore.printStackTrace();
					}
				}
			}
		}
		return isAdmin;
	}

	//Méthode de test de l'administrateur
	public boolean isAdmin(HttpServletRequest request) throws SQLException {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultat = null;
	    boolean isAdmin = false;
	    String pseudo = (String) request.getParameter("pseudo");
	    String mdp = (String) request.getParameter("password");
	    
	    if(pseudo != null && mdp != null) {
	    	try {
	    		Class.forName("com.mysql.jdbc.Driver");
		        connexion = (Connection) DriverManager.getInstance().getConnection();
	    		statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Users where pseudo=? and password=?");
		        statement.setString(1, pseudo);
		        statement.setString(2,  mdp);
		        resultat = statement.executeQuery();
	        } catch ( SQLException e ) {
	        	e.printStackTrace();
		    } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				
		        if ( resultat != null ) {
		            try {
		            	if(found(resultat)) {
		            	isAdmin= resultat.getBoolean("isAdmin");
		            	}
		                resultat.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
		        if ( statement != null ) {
		            try {
		                statement.close();
		            } catch ( SQLException ignore ) {
		            }
		        }
		        if ( connexion != null ) {
		            try {
		                connexion.close();
		            } catch ( SQLException ignore ) {
		            	ignore.printStackTrace();
		            }
		        }
			}
	    }
	    return isAdmin;
	}
	
	public boolean found(ResultSet r) throws SQLException {
		return r.next();
	}

	
	//TODO a modifier (Done normalement)
	/**
	 * enregisterJoueur : ajoute dans la BDD un nouvel utilisateur
	 * @param request
	 * @return succes/echec
	 */
	public boolean insertUser(HttpServletRequest request) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    ResultSet resultat = null;
	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
			String pseudo = (String) request.getParameter("pseudo");
	        statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Users WHERE pseudo = ? ;");
	        statement.setString(1, pseudo);
	        resultat = statement.executeQuery();
	        String password = resultat.getString("password");
			String question = resultat.getString("question");
			String answer = resultat.getString("answer");


			if(!resultat.next()) {
	        	statement = (PreparedStatement) connexion.prepareStatement("INSERT INTO Users (`pseudo`, `password`, `question`, `answer`, `isEditor`, `isAdmin`) VALUES (?,?,?,?,0,0);");
		        statement.setString(1, pseudo);
		        statement.setString(2, password);
		        statement.setString(3, question);
		        statement.setString(4, answer);
		        statement.execute();
		        statement.close();
		        System.out.println("Inscription reussi");
		        return true;
	        } else {
	        	// pseudo deja utilise
	        	System.out.println("pseudo deja utilise");
	        	return false;
	        }	        
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return false;
	}





//*******************************************************USELESS***************************************************************

	/**
	 * enregisterPartie : ajoute dans la BDD une nouvelle Partie
	 * @param pseudo
	 * @param game
	 * @return succes/echec
	 */
	public void enregisterPartie(String pseudo, String game) {  //TODO changer pour Groupe
		Connection connexion = null;
	    PreparedStatement statement = null;
	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        statement = (PreparedStatement) connexion.prepareStatement("INSERT INTO Matchs (`pseudo`, `gameName`, `hBegin`) VALUES (?,?,CURRENT_TIMESTAMP());");
	        statement.setString(1, pseudo);
	        statement.setString(2, game);
	        System.out.println(pseudo+game);
	        statement.execute();
	        statement.close();
	        System.out.println("Le jeu va commencé");
	    } catch (SQLException e ) {
		   	e.printStackTrace();
		}
	}
	
	public void enregistrerStop(String pseudo, String game) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        statement = (PreparedStatement) connexion.prepareStatement("UPDATE Matchs SET hEnd=CURRENT_TIMESTAMP() WHERE idMatch in (SELECT * FROM (SELECT max(idMatch) FROM Matchs WHERE pseudo=?) AS tmp) ;");
	        statement.setString(1,pseudo);
	        statement.execute();
	        statement.close();
	        System.out.println("Le partie est terminée");
	    } catch (SQLException e ) {
		   	e.printStackTrace();
		}
	}


	public ResultSet getGames() {
		Connection connexion = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	        statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Games;");
	      return( statement.executeQuery());
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return null;
	}


	public void addGame(HttpServletRequest request) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String name = (String) request.getParameter("name");
		   String info = (String) request.getParameter("infos");
		   String release = (String) request.getParameter("release");
		   System.out.println("Ajout d'un jeu : " +name + " " + info + " " + release);
		   
		   try {
		        connexion = (Connection) DriverManager.getInstance().getConnection();

				   statement = (PreparedStatement) connexion.prepareStatement("INSERT INTO Games (`name`, `infos`, `release`, `isShowed`) VALUES (?,?,?,?)");
			        statement.setString(1, name);
			        statement.setString(2, info);
			        statement.setString(3, release);
			        statement.setString(4, "1");
			        statement.execute();
			        statement.close();
			   
		                      
		    } catch (SQLException e ) {
		    	e.printStackTrace();
		    }
	}

//***************************************************END_USELESS*******************************************************************







	/**
	 * deleteEtu : supprime dans la BDD un etudiant
	 * @param request
	 * @return succes/echec
	 */

	public void deleteEtu( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Delete From Etudiants where numetudiant = ? ;");
			statement.setString(1, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * deleteGroup : supprime dans la BDD un groupe
	 * @param request
	 * @return succes/echec
	 */

	public void deleteGroup( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String idGroupe = (String) request.getParameter("idGroupe");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Delete From Groupes where idGroupe = ? ;");
			statement.setString(1, idGroupe);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	
	public ResultSet getAllEtudiants() {
		Connection connexion = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	        statement = (PreparedStatement) connexion.prepareStatement("SELECT * FROM Etudiants;");
	      return( statement.executeQuery());
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return null;
	}
	
	
	
	public ResultSet getAllGroups() {
		Connection connexion = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	        statement = (PreparedStatement) connexion.prepareStatement("select * from Groupes;");
	      return( statement.executeQuery());
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return null;
	}



	//TODO Les (14-1) fonctions pour changer les attributs des étudiants, (all done)
	//TODO (5-1) pour changer les attributs des groupes (4 done) (y compris la liste d'étudiants) et les 3 pour ceux d'un utlisateur CONNECTE  (done)
	//TODO attention tout de fois au val des var (newmdp et prenom qui se repete)


	// Etudiants fonctions de modification


	/**
	 * changePrenom : modifie le prenom dans la BDD d'un etudiant
	 * @param request
	 */

	public void changePrenom(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("prenom");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set prenom = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeNom : modifie le nom dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeNom(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("nom");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set nom = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeDdn : modifie la date de naissance dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeDdn(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("ddn");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set ddn = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeEmailPro : modifie l'email pro dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeEmailPro(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("emailPro");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set emailPro = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeEmailPerso : modifie l'email perso dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeEmailPerso(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("emailPerso");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set emailPerso = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


	/**
	 * changeBac : modifie le bac dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeBac(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("bac");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set bac = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeAnBac : modifie l'annee d'obtention du bac dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeAnBac(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("anBac");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set anBac = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeMenBac : modifie la mention du bac dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeMenBac(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("menBac");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set menbac = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeDiplome : modifie le diplome dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeDiplome(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("diplome");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set diplome = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


	/**
	 * changeMenBac : modifie l'annee d'obtention du diplome dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeAnDiplome(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("anDiplome");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set anDiplome = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * change : modifie la ville d'obtention du diplome dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeVilleDiplome(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("villeDiplome");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set villeDiplome = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeMenBac : modifie le sexe dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeS(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("S");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set S = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeMenBac : modifie l'annee d'inscription a une formation dans la BDD d'un etudiant
	 * @param request
	 */

	public void changeInscription(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String prenom = (String) request.getParameter("inscription");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Etudiants set inscription = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	// Groupes fonctions de modification


	/**
	 * addEtuInGroup : ajoute dans un groupe de la BDD un etudiant
	 * @param request
	 */

	//TODO
	public void addEtuInGroup( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String idgroupe = (String) request.getParameter("idGroupe");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Insert Into ListeEtudiants values (?,?);");
			statement.setString(1, numetudiant);
			statement.setString(2, idgroupe);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


	/**
	 * addEtuInGroup : ajoute dans un groupe de la BDD un etudiant
	 * @param request
	 */

	//TODO
	public void addGroupInGroup( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String idGroup = (String) request.getParameter("idGroup");  //TODO a voir si ok
		String idGroupeOut = (String) request.getParameter("idGroupeOut");

		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
														//maj	 //selection des etudiants a ajouter puis mise à jour de leur appartenance au groupe
			String query = "Insert Into ListeEtudiants ( update (select * from ListeEtudiants where idGroupe = ?  and numetudiant not in " +
																	"(select * from ListeEtudiant where idGroup = ?)" +
														") set idGroupe = ?);";
			statement = (PreparedStatement) connexion.prepareStatement(query);
			statement.setString(1, idGroupeOut);
			statement.setString(2, idGroup);
			statement.setString(3, idGroup);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * deleteEtu : supprime dans un groupe de la BDD un etudiant
	 * @param request
	 */

	public void deleteEtuFromGroup( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("numetudiant");
		String idgroupe = (String) request.getParameter("idGroupe");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Delete From ListeEtudiants where numetudiant = ? and idGroupe = ? ;");
			statement.setString(1, numetudiant);
			statement.setString(2, idgroupe);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * deleteGroupFromGroup : supprime dans un groupe de la BDD un groupe
	 * @param request
	 */

	public void deleteGroupFromGroup( HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String idGroup = (String) request.getParameter("idGroup");  	 //TODO a voir si ok
		String idGroupeOut = (String) request.getParameter("idGroupeOut");

		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
				 										//selection des etudiants a supprimer
			String query = "delete from ListeEtudiants (select * from ListeEtudiants where idGroupe = ?  and numetudiant in " +
					"(select * from ListeEtudiant where idGroup = ?)" +
					") where idGroupe = ?;";
			statement = (PreparedStatement) connexion.prepareStatement(query);
			statement.setString(1, idGroupeOut);
			statement.setString(2, idGroup);
			statement.setString(3, idGroup);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeNomGroupe : modifie le nom la BDD d'un groupe
	 * @param request
	 */

	public void changeNomGroupe(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("idGroupe");
		String prenom = (String) request.getParameter("nomGroupe");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Groupes set nomGroupe = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeNomProprietaire : modifie le proprietaire dans la BDD d'un groupe
	 * @param request
	 */

	public void changeNomProprietaire(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("idGroupe");
		String prenom = (String) request.getParameter("nomProprietaire");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Groupes set nomProprietaire = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeDateCreation : modifie la date de creation dans la BDD d'un groupe
	 * @param request
	 */

	public void changeDateCreation(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String numetudiant = (String) request.getParameter("idGroupe");
		String prenom = (String) request.getParameter("dateCreation");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Groupes set dateCreation = ? where numetudiant = ? ;");
			statement.setString(1, prenom);
			statement.setString(2, numetudiant);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


		// Users fonctions de modification

	/**
	 * changeMDP: modifie le mot de passe dans la BDD d'un utilisateur (une fois connecté)
	 * @param request
	 */

	public void changeMDP(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String pseudo = (String) request.getParameter("pseudo");
		String newMdp = (String) request.getParameter("NewPassword");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Users set password = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}



	public void mdpOublie(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		PreparedStatement statement2 = null;
		ResultSet resultat = null;

		String pseudo = (String) request.getParameter("pseudo");
		String answer = (String) request.getParameter("answer");  //reponse donnée a la question personelle pour autoriser la modification
		String check = null; // reponse enregistrée dans la BDD a la question personelle
		String newMdp = (String) request.getParameter("NewPassword");

		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement2 = (PreparedStatement) connexion.prepareStatement("select answer from Users where pseudo = ?;");
			statement2.setString(1, pseudo);
			resultat = statement.executeQuery();
			if(resultat != null && resultat.next()) {
				check = resultat.getString("answer");
			}
			if (check==answer) {
				statement = (PreparedStatement) connexion.prepareStatement("Update Users set password = ? where pseudo = ? ;");
				statement.setString(1, newMdp);
				statement.setString(2, pseudo);
				statement.execute();
				statement.close();
			}
			else{
				System.out.println("Reponse a la question incorrect");
			}
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


	/**
	 * changeQuestion : modifie la question personnelle dans la BDD d'un utilisateur (une fois connecté)
	 * @param request
	 */

	public void changeQuestion(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String pseudo = (String) request.getParameter("pseudo");
		String newMdp = (String) request.getParameter("question");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Users set question = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeAnswer : modifie la reponse a la question personnelle dans la BDD d'un utilisateur (une fois connecté)
	 * @param request
	 */

	public void changeAnswer(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String pseudo = (String) request.getParameter("pseudo");
		String newMdp = (String) request.getParameter("answer");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Users set answer = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeToEditor : modifie le droit d'edition (0 ou 1) dans la BDD d'un utilisateur
	 * @param request
	 */

	public void changeToEditor(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String pseudo = (String) request.getParameter("pseudo");
		String newMdp = (String) request.getParameter("isEditor");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Users set isEditor = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * changeToAdmin : modifie le droit d'administration (0 ou 1) dans la BDD d'un utilisateur
	 * @param request
	 */

	public void changeToAdmin(HttpServletRequest request) {
		Connection connexion = null;
		PreparedStatement statement = null;
		String pseudo = (String) request.getParameter("pseudo");
		String newMdp = (String) request.getParameter("isAdmin");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Users set isAdmin = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();
		} catch (SQLException e ) {
			e.printStackTrace();
		}
	}


//*******************************************************USELESS***************************************************************

	public ResultSet getFinishedMatchs() {
		Connection connexion = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	
	        statement = (PreparedStatement) connexion.prepareStatement("select * from Matchs where hEnd is not  NULL;");
	      return( statement.executeQuery());
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return null;
	}
	
	public ResultSet getPlays(String pseudo) {
		Connection connexion = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	        statement = (PreparedStatement) connexion.prepareStatement("select count(*) from Matchs where pseudo = ?;");
	       
	        statement.setString(1, pseudo);
	      return( statement.executeQuery());
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return null;
	}
	


	
	public void ban(HttpServletRequest request) {
		
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String pseudo = (String) request.getParameter("pseudo");
		   String ban = (String) request.getParameter("ban");
		   int abs = Math.abs( Integer.parseInt(ban) -1);
		   ban = Integer.toString(abs);
		
		   try {
		        connexion = (Connection) DriverManager.getInstance().getConnection();

				    statement = (PreparedStatement) connexion.prepareStatement("Update Players set ban = ? where pseudo = ?  ");
			        statement.setString(1, ban);
			        statement.setString(2, pseudo);
			        statement.execute();
			        statement.close();
			   
		                      
		    } catch (SQLException e ) {
		    	e.printStackTrace();
		    }
		
		 
	}
	
	
	public void end(HttpServletRequest request) {
		
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String id = (String) request.getParameter("id");
	
		  Date dNow = new Date();
	      SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
	     String d = ft.format(dNow) ;
			   
		   try {
		        connexion = (Connection) DriverManager.getInstance().getConnection();

				    statement = (PreparedStatement) connexion.prepareStatement("Update Matchs set hEnd = ? where idMatch = ? ;");
			        statement.setString(1, d);
			        statement.setString(2, id);
			        statement.execute();
			        statement.close();
			   	                      
		} catch (SQLException e ) {
		    	e.printStackTrace();
	    }
		
	
		 
	}

	public void setShow(HttpServletRequest request, Boolean b) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String name = request.getParameter("name");
	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        /* Verification pseudo */
	        statement = (PreparedStatement) connexion.prepareStatement("update Games set isShowed = ? where name = ?;");
	        statement.setBoolean(1, b);
	        statement.setString(2, name);
	        statement.executeUpdate();
	                      
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
	}

			
	/*public void changeMDP(HttpServletRequest request) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String pseudo = (String) request.getParameter("pseudo");
	    String newMdp = (String) request.getParameter("NewPassword");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Players set password = ? where pseudo = ? ;");
			statement.setString(1, newMdp);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();        
		} catch (SQLException e ) {
		    e.printStackTrace();
	    }
	}*/

	
	public String getEmail(String pseudo) {
		Connection connexion = null;
		ResultSet resultat = null;
	    PreparedStatement statement = null;

	    /* Connexion à la base de données */
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        statement = (PreparedStatement) connexion.prepareStatement("select email from Players where pseudo = ?;");
	        statement.setString(1, pseudo);
	        resultat = statement.executeQuery();
	        if(resultat != null && resultat.next()) {
	        	return resultat.getString("email");
	        }
	    } catch (SQLException e ) {
	    	e.printStackTrace();
	    }
		return "";
	}

	public void changeEmail(HttpServletRequest request) {
		Connection connexion = null;
	    PreparedStatement statement = null;
	    String pseudo = (String) request.getParameter("pseudo");
	    String newEmail = (String) request.getParameter("newEmail");
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Update Players set email = ? where pseudo = ? ;");
			statement.setString(1, newEmail);
			statement.setString(2, pseudo);
			statement.execute();
			statement.close();        
		} catch (SQLException e ) {
		    e.printStackTrace();
	    }
	}
	
	public ResultSet getPreferedGames(HttpServletRequest request) {
		Connection connexion = null;
		ResultSet resultat = null;
	    PreparedStatement statement = null;
	    String pseudo = (String) request.getAttribute("pseudo");
	    try {
	        connexion = (Connection) DriverManager.getInstance().getConnection();
	        statement = (PreparedStatement) connexion.prepareStatement("select * from PreferedGames where pseudo = ?;");
	        statement.setString(1, pseudo);
	        return statement.executeQuery();
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    }
		return null;	
	}

	public void removePreferedGames(String pseudo) {
		Connection connexion = null;
	    PreparedStatement statement = null;
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("Delete From PreferedGames where pseudo = ? ;");
			statement.setString(1, pseudo);   
			statement.execute();
			statement.close();               
		    } catch (SQLException e ) {
		    	e.printStackTrace();
		    }
	}

	public void addPreferedGames(String pseudo, String game) {
		Connection connexion = null;
	    PreparedStatement statement = null;
		try {
			connexion = (Connection) DriverManager.getInstance().getConnection();
			statement = (PreparedStatement) connexion.prepareStatement("INSERT INTO PreferedGames (`pseudo`, `gameName`) VALUES (?,?);");
			statement.setString(1, pseudo);
			statement.setString(2, game);
			statement.execute();
			statement.close();               
		    } catch (SQLException e ) {
		    	e.printStackTrace();
		    }
	}
		
	
	
	
}

