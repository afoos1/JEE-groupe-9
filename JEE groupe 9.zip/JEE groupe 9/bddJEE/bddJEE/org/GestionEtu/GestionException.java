package org.GestionEtu;

public  class GestionException extends Exception{
	
	public GestionException(String s){
		super(s);
	}	
}
