Instruction d’installation : 
Installez IntelliJ version Ultimate. Pour ce faire, rendez vous sur le site https://www.jetbrains.com, 
créez votre compte identifié par votre adresse rennes1. Cela vous donnera accès à une licence gratuite d’un an. 
Téléchargez ensuite IntelliJ Ultimate.

MySQL : 
Lancer mysql
Créez une base de donnée "enssat"
executer la commande :
	source path/to/jee.sql
Cette commande va creer la base de données. Puis :
	source path/to/src.sql
Cette commande va remplir la base de données avec les étudiants du webservice. Puis :
Créez un utilisateur : grant all privileges on *.* to 'test'@'localhost' identified by 'password';



Etape 1 : Dezippez le fichier war :
jar -xvf MyWar.war
Etape 2 : Allez dans le repertoire Web-Inf
cd WEB-INF
Etape 3 : Exécutez le programme avec toutes les dépendances
java -classpath "lib/*:classes/." my.packages.destination.FileToRun


Reliez votre serveur Tomcat à IntelliJ 

Lancez le serveur Tomcat, vous arriverez sur la page de connexion.


